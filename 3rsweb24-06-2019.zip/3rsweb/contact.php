<?php session_start(); 
include('header.php');?>
<body class="multipage not-front contacts-page">

<div id="main">

    <div id="home">
        <div id="top">
            <div class="top2_wrapper" id="top2">
                <div class="container">
                 
                    <div class="top2 clearfix">
                        <header>
                            <div class="logo_wrapper">
                                <a href="http://trinibagorealestate.com/3rsweb/" class="logo scroll-to">
                                    <img src="images/3wrs_logo.png" width="170" height="auto" alt="" class="img-responsive">
                                </a>
                            </div>
                        </header>
                        <div class="navbar navbar_ navbar-default">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="navbar-collapse navbar-collapse_ collapse">
                                <ul class="nav navbar-nav sf-menu clearfix">
                                    <li><a href="http://trinibagorealestate.com/3rsweb/index.php#home">Home</a>
                                       <!--  <ul>
                                            <li><a href="index-2.html">Black Style 1</a></li>
                                            <li><a href="index-white.html">White Style 2</a></li>
                                        </ul> -->
                                    </li>
                                    <li><a href="http://trinibagorealestate.com/3rsweb/index.php#about">About us</a></li>
                                    <li><a href="http://trinibagorealestate.com/3rsweb/index.php#services">Services</a></li>
                                    <li><a href="http://trinibagorealestate.com/3rsweb/index.php#clients">Clients</a></li>
                                   <!--  <li class="sub-menu sub-menu-1"><a href="#">Sections<em></em></a>
                                        <ul>
                                            <li><a href="#department">Design Department</a></li>
                                            <li><a href="#features">Features</a></li>
                                            <li><a href="#difference">Difference</a></li>
                                            <li><a href="#pricelist">Pricelist</a></li>
                                            <li><a href="#gallery">Mock-up</a></li>
                                        </ul>
                                    </li> -->
                                    <!-- <li><a href="gallery.html">Gallery</a></li> -->
                                    <!-- <li class="sub-menu sub-menu-1"><a href="#">Blog<em></em></a>
                                        <ul>
                                            <li><a href="blog.html">Left Blog</a></li>
                                            <li><a href="blog-right.html">Right Blog</a></li>
                                            <li><a href="post.html">blog post 2 columns</a></li>
                                            <li><a href="post-full.html">blog post 1 column</a></li>
                                        </ul>
                                    </li> -->
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="subpage-slider">

            </div>

        </div>
    </div>

    <div class="breadcrumbs1_wrapper">
        <div class="container">
            <div class="breadcrumbs1"><a href="http://template-preview.com/bootstrap-templates/black-white/index.html">Home</a><span>/</span>contact us</div>
        </div>
    </div>

    
         
    <div id="content">
        <div class="container">

            <h1>DON’T HESITATE CONTACT US</h1>

            <div class="row">
                <div class="col-sm-8">
                    <?php
                            if(isset($_SESSION['msg']) && $_SESSION['msg']!='')
                                {
                                         echo "<div class='col-md-12'>";
                                        echo "<div class='alert alert-success'>";
                                        echo  $_SESSION['msg'];
                                        echo "</div>";
                                        echo "</div>";
                                    
                                
                                echo $_SESSION['msg']='';
                                }
                        ?>

                    <div class="content-part">
                        <div id="note"></div>
                        <div id="fields">
                            <form id="ajax-contact-form" method="POST" class="form-horizontal" action="send_email.php">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="inputName">Your Name</label>
                                            <input type="text" class="form-control" id="" name="name"
                                                  placeholder="Your Name">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="inputEmail">Company Name</label>
                                            <input type="text" class="form-control" id="" name="companyname" placeholder="Company Name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="inputName">Phone Number</label>
                                            <input type="text" class="form-control" id="" name="conatct" placeholder="Phone Number"> 
                                                   
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="inputEmail">Email</label>
                                            <input type="text" class="form-control" id="" name="email" placeholder="Email">
                                                   
                                        </div>
                                    </div>
                                </div>

                               


                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="inputMessage">Your Question / Feedback</label>
                      <textarea class="form-control" rows="10" id="" name="feedback" placeholder="Questiuon/Feedback"></textarea>
                                
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn-default btn-cf-submit">Send message</button>
                            </form>
                        </div>
                    </div>

                </div>
                <div class="col-sm-4">

                    <div class="sidebar-part">
                        <h5>Address</h5>

                        <p>
                            3RS Web & IT Solutions<br/>
                            #14 B Diego Martin Main Road<br/>
                            Diego Martin<br/>
                            Trinidad & Tobago, W.I.

                        </p>

                        <!-- <div class="hl2"></div>

                        <h5>contact info</h5>

                        <p>
                            E-mail: support@test-demo.com<br>
                            Telephone: +1 (917) 338 6810<br>
                            FAX: +1 (917) 338 6810
                        </p>

                        <div class="hl2"></div>

                        <h5>working hours</h5>

                        <p>
                            Monday to Friday from 09.00 to 18.00
                        </p> -->
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d490.06743813582557!2d-61.555237073456794!3d10.692806971729615!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8c3608ff28e951e3%3A0xbdaac450311097d9!2s14+Diego+Martin+Main+Rd%2C+Diego+Martin%2C+Trinidad+and+Tobago!5e0!3m2!1sen!2sin!4v1560253991296!5m2!1sen!2sin" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
        </div>
    </div>


    <?php include('footer.php');?>


</div>
<script src="http://template-preview.com/bootstrap-templates/black-white/js/bootstrap.min.js"></script>
</body>


</html>