<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>
<body class="onepage front" data-spy="scroll" data-target="#top" data-offset="81">

<div id="load"></div>

<div id="main">

    <div id="home">
        <div id="top">
           
                <?php include('top_menu.php');?>
            <div class="front-slider">
                <div id="mission">
                    <a class="mission_prev" href="#"></a>
                    <a class="mission_next" href="#"></a>

                    <div class="carousel-box">
                        <div class="inner">
                            <div class="carousel main">
                                <ul>
                                    <li>
                                        <div class="mission container">
                                            <div class="mission_inner">
                                                <div class="slider_text">Your website is the window of your business, keep it fresh, keep it modern. </div>
                                               <!-- <div class="txt2">YourDomain.com - Minimalistic, Beautiful Bootstrap &
                                                    Wordpress Responsive Templates
                                                </div>-->
                                                <!--<div class="txt3"><a href="#" class="btn-default btn0">Learn More</a><a
                                                        href="#" class="btn-default btn0">Read More</a></div>-->
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="mission container">
                                            <div class="mission_inner">
                                                <div class="slider_text">A journey of a thousand sites begins with a single click.</div>
                                                <!--<div class="txt2">YourDomain.com - Minimalistic, Beautiful Bootstrap &
                                                    Wordpress Responsive Templates
                                                </div>-->
                                                <!--<div class="txt3"><a href="#" class="btn-default btn0">Learn More</a><a
                                                        href="#" class="btn-default btn0">Read More</a></div>-->
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="mission container">
                                            <div class="mission_inner">
                                                <div class="slider_text">Data is king.</div>
                                                <!--<div class="txt2">YourDomain.com - Minimalistic, Beautiful Bootstrap &
                                                    Wordpress Responsive Templates
                                                </div>-->
                                                <!--<div class="txt3"><a href="#" class="btn-default btn0">Learn More</a><a
                                                        href="#" class="btn-default btn0">Read More</a></div>-->
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="mission container">
                                            <div class="mission_inner">
                                                <div class="slider_text">Design is not just what it looks like and feels like, design is how it works – Steve Jobs</div>
                                                <!--<div class="txt2">YourDomain.com - Minimalistic, Beautiful Bootstrap &
                                                    Wordpress Responsive Templates
                                                </div>-->
                                               <!-- <div class="txt3"><a href="#" class="btn-default btn0">Learn More</a><a
                                                        href="#" class="btn-default btn0">Read More</a></div>-->
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div id="about">
        <div class="container">
            <div class="title1 animated" data-animation="fadeInUp" data-animation-delay="200">WELCOME TO 3RS Web & IT Solutions
            </div>
            <br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="about1 clearfix animated" data-animation="fadeInRight" data-animation-delay="500">
                        <p>3RS Web & IT Solutions was founded May 1, 2000 with the focus on meeting the rapidly growing needs of developing and maintaining a strong and effective web presence by businesses of all industries. 3RS provides professional web page and application development with the added value of business analysis and a marketing strategy consultation.
                        </p>
                        <p>We provide development for small, medium and large companies in Trinidad and Tobago at affordable prices. Development driven by developing web sites and IT applications for different industries such as distribution, marketing, accounting, catering, real estate agents, schools, financial institutions and shipping to name a few.
                        </p>
                        <p>3RS is dedicated to developing the highest quality web sites on the Internet by incorporating state-of-the-art technology with the experience and knowledge of highly skilled programmers and business analysts. If you are a professional looking to take your business to the next level or would simply like to create an information portal for online visitors, let 3RS develop an effective plan, design the content, graphics and layout, allowing you to reach your target audience.
                        </p>
                    </div>
                </div>
            </div>
            <br><br>
            <div class="macs animated" data-animation="fadeInUp" data-animation-delay="600"><img src="images/macs.png" alt="" class="img-responsive">
            </div>
        </div>
    </div>

    <div id="services">
        <div class="container">
            <div class="title1 animated">OUR SERVICES</div>
        </div>
    </div>

    <div id="services2_wrapper">
        <div id="services2">
            <div class="left_box_wrapper">
                <div class="left_box clearfix">

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="services2 nav1 animated" data-animation="fadeIn" data-animation-delay="200">
                                <div class="ic1"><i class="fa fa-edit"></i></div>
                                <div class="txt1">Professional Website and Application Development</div>
                                <div class="txt2">3RS Web & IT Solutions is a professional Internet strategy and Web design company. We specialize in best-in-class website design, application development, online marketing and Flash multimedia. 3RS features an integrated team of web consultants, creative designers, writers, programmers and marketing professionals that know how to get online results. 
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="services2 nav2 animated" data-animation="fadeIn" data-animation-delay="300">
                                <div class="ic1"><i class="fa fa-connectdevelop"></i></div>
                                <div class="txt1">Internet Marketing Services</div>
                                <div class="txt2">With years of Internet Marketing experience, 3RS has the knowledge and expertise to help your business increase exposure on major search engines and portals while managing your online spending. Our products and services were developed with our customer's needs in mind and the result is a full service search marketing solution, from strategic consultation to in-depth reporting systems.
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="services2 nav3 animated" data-animation="fadeIn" data-animation-delay="400">
                                <div class="ic1"><i class="fa fa-life-ring"></i></div>
                                <div class="txt1">Consulting and Support</div>
                                <div class="txt2">3RS is a rapidly growing custom software development company. We specialize in the development of custom software applications and offshore software outsourcing services. Specifically, our company carries out custom programming, database design, client-server and software application development.

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="services2 nav4 animated" data-animation="fadeIn" data-animation-delay="500">
                                <div class="ic1"><i class="fa fa-windows"></i></div>
                                <div class="txt1">mobile application</div>
                                <div class="txt2">We bring in an analytical and systematic approach to technology consulting, design, technology architecture formulation and application of technology to create real business value to your business. Our consulting services are centered on helping firms understand the link between business processes and the technologies.

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="right_box_wrapper"></div>
        </div>
    </div>

   <div id="client">
        <div class="container">
            <div class="title1 animated"> OUR CLIENTS</div>
            <br>
            <div class="row">
                <div class="col-sm-12">
                     <p>3RS Web & IT Solutions has designed, developed and deployed world-class technology solutions created specifically to meet and exceed the unique requirements of each client. 3RS has thrived largely as a result of our unyielding commitment to our clients, strategic partners and employees.
                    </p>
                    <p>With a highly diverse staff of cross-skilled professionals, 3RS brings the experience required to deliver truly superior solutions for today's sophisticated marketplace. 3RS is proud to have worked with hundreds of great clients, ranging from globally recognized brands to local small businesses. We challenge our clients to justify the investment that we are asking them to make and establish success metrics by which the investment will be measured.
                    </p>
                     <p>We also pride ourselves on recommending and delivering cost-effective solutions which are in exact alignment with the unique needs of each project, always seeking to maximize the value of previous technology investments while providing clear and unbiased advice regarding best practices. We challenge our employees and our clients to learn from the past, seize the opportunities of today, and plan for the challenges of tomorrow.</p>
                </div>
            </div>

            <div class="row">
                <section class="customer-logos slider">
                 <!-- <div class="slide"><a href="javascript:void(0);" target="_blank"><img src="images/sites/bryden_pi.jpg" alt="Bryden Pi" title="Bryden Pi"></a></div>-->
                  <div class="slide"><a href="http://cardkonnect.com/" target="_blank"><img src="images/sites/cardkonnect.jpg" tiltle="CardKonnect"></a></div>
                  <div class="slide"><a href="https://www.ncpdtt.org/" target="_blank"><img src="images/sites/NCPD-Homepage.jpg" title="NCPD"></a></div>
                  <div class="slide"><a href="http://trinidadeventspaces.com/" target="_blank"><img src="images/sites/trinidadeventspaces.jpg" title="Trinidad Event Spaces"></a></div>
                  <div class="slide"><a href="http://trinidadproperties.biz/" target="_blank"><img src="images/sites/trinidadproperties.jpg" title="Trinindad Properties"></a></div>
                  <div class="slide"><a href="http://trinidadrealtor360.com/" target="_blank"><img src="images/sites/trinidadrealtor360.jpg" title="Trinidad Realtor 360"></a></div>
                 
            </section>
            </div>
        </div>
    </div> 

    <?php include('footer.php'); ?>


</div>
<script>$(document).ready(function(){
    $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 4
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 3
            }
        }]
    });
});</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>


</html>