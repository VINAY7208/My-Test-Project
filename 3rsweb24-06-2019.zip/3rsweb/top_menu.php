 <div class="top2_wrapper" id="top2">
                <div class="container">
                 
                    <div class="top2 clearfix">
                        <header>
                            <div class="logo_wrapper">
                                <a href="http://trinibagorealestate.com/3rsweb/" class="logo scroll-to">
                                    <img src="images/3wrs_logo.png" width="170" height="auto" alt="" class="img-responsive">
                                </a>
                            </div>
                        </header>
                        <div class="navbar navbar_ navbar-default">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="navbar-collapse navbar-collapse_ collapse">
                                <ul class="nav navbar-nav sf-menu clearfix">
                                    <li><a href="#home">Home</a>
                                       <!--  <ul>
                                            <li><a href="index-2.html">Black Style 1</a></li>
                                            <li><a href="index-white.html">White Style 2</a></li>
                                        </ul> -->
                                    </li>
                                    <li><a href="#about">About us</a></li>
                                    <li><a href="#services">Services</a></li>
                                    <li><a href="#client">Clients</a></li>

                                   <!--  <li class="sub-menu sub-menu-1"><a href="#">Sections<em></em></a>
                                        <ul>
                                            <li><a href="#department">Design Department</a></li>
                                            <li><a href="#features">Features</a></li>
                                            <li><a href="#difference">Difference</a></li>
                                            <li><a href="#pricelist">Pricelist</a></li>
                                            <li><a href="#gallery">Mock-up</a></li>
                                        </ul>
                                    </li> -->
                                    <!-- <li><a href="gallery.html">Gallery</a></li> -->
                                    <!-- <li class="sub-menu sub-menu-1"><a href="#">Blog<em></em></a>
                                        <ul>
                                            <li><a href="blog.html">Left Blog</a></li>
                                            <li><a href="blog-right.html">Right Blog</a></li>
                                            <li><a href="post.html">blog post 2 columns</a></li>
                                            <li><a href="post-full.html">blog post 1 column</a></li>
                                        </ul>
                                    </li> -->
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>