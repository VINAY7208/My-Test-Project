<?php session_start();
    $name = $_POST['name'];
    $companyname = $_POST['companyname'];
    $conatct = $_POST['conatct'];
    $email = $_POST['email'];
    $feedback = $_POST['feedback'];
    $subject = "Enquiry From 3RS Web Solutions Website" ;
    $body = '<html>
    <head>  
    </head>
    <body style="background-color:#f9f9f9; padding: 15px;" >  
    <a href="javascript:void(0);" target="_blank"><img src="http://trinibagorealestate.com/3rsweb/images/3wrs_logo.png" height="32" width="150" border="0"></a>
    <h4>You have recieved a enquiry from your 3RS website with following details.</h4>
    <p>Name : '.$name.'</p>
    <p>Company Name : '.$companyname.'</p>
    <p>Phone Number : '.$conatct.'</p>
    <p>Email : '.$email.'</p>
    <p>Question/Feedback : '.$feedback.'</p>
    </body>
    </html>';
    $headers = 'From: 3rsweb info@3rswebsolutions.com' . "\r\n" ;
    // $headers .= "Cc:alexaglobalsofttech@gmail.com \r\n";
    $headers .= "Bcc:vinay7208@gmail.com \r\n";
    $headers .='Reply-To: '. $to . "\r\n" ;
    $headers .='X-Mailer: PHP/' . phpversion();
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
    
    if(mail('agst.vinay@gmail.com', $subject, $body,$headers)) 
    {
        $msg = "Email has been sent succcessfully. We will get back to you with in 24 hrs.";
        $_SESSION['msg'] = $msg;
    }
    else
    {
        echo("<p>Email Message delivery failed...</p>");
    }
    
    header('Location:contact.php');
    exit();
?>