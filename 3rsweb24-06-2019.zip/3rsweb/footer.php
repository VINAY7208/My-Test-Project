<div class="bot1">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="logo2_wrapper">
                        <a href="#home" class="logo2 scroll-to">
                            <img src="images/3wrs_logo.png" alt="" class="img-responsive">
                        </a>
                    </div>
                    <p>
                        3RS Web & IT Solutions is an information technology firm offering strategic online and innovative digital business solutions.

                    </p>
                    <br>
                    <ul class="social clearfix">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <div class="bot_title">Quick Links</div>
                    <ul class="bot_menu clearfix">
                        <li><a href="http://trinibagorealestate.com/3rsweb/#about">About Us</a></li>
                        <li><a href="http://trinibagorealestate.com/3rsweb/#services">Services</a></li>
                        <li><a href="http://trinibagorealestate.com/3rsweb/#client">Clients</a></li>
                        <li><a href="http://trinibagorealestate.com/3rsweb/contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <div class="bot_title">company address</div>
                    <div class="smallicons clearfix">
                        <i class="fa fa-map-o"></i>
                        <span>3RS Web & IT Solutions<br/>
                        #14 B Diego Martin Main Road<br/>
                        Diego Martin<br/>
                        Trinidad & Tobago, W.I.
                        </span>
                    </div>
                    <!-- <div class="smallicons clearfix">
                        <i class="fa fa-phone"></i><span>Phone: +1 (917) 3386810</span>
                    </div> -->
                    <!-- <div class="smallicons clearfix">
                        <i class="fa fa-envelope-o"></i><span>Email: <a href="#">support@test-demo.com</a></span>
                    </div> -->
                   <!--  <div class="smallicons clearfix">
                        <i class="fa fa-print"></i><span>FAX: +1 (917) 3386810</span>
                    </div> -->
                </div>
                <div class="col-sm-3">
                    <div class="bot_title">Our Services</div>
                    <ul class="bot_menu clearfix">
                        <li><a href="http://trinibagorealestate.com/3rsweb/index.php#services">Professional Website and Application Development</a></li>
                        <li><a href="http://trinibagorealestate.com/3rsweb/index.php#services">Internet Marketing Services</a></li>
                        <li><a href="http://trinibagorealestate.com/3rsweb/index.php#services">Consulting and Support</a></li>
                        <li><a href="http://trinibagorealestate.com/3rsweb/index.php#services">Mobile Application</a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="bot2">
        <div class="container">
            copyright &copy; <?php echo date('Y'); ?>,   3RS Web Solutions.
            All Rights Reserved
        </div>
    </div>